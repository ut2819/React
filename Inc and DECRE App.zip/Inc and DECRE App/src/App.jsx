import React, { useState } from "react";
import "./index.css";
import AddIcon from '@mui/icons-material/Add';
import MinimizeIcon from '@mui/icons-material/Minimize';
import RestartAltIcon from '@mui/icons-material/RestartAlt';
import ToDoList from "./ToDoList";
const App=()=>{
  const [input,setInput]=useState(0);
  const inputEvent=()=>{
      setInput(input+1)
  }
  const decre=()=>{
    if(input!=0){
    setInput(input-1);
    }}
    const res=()=>{
        setInput(0);
    }
    return(
        <>
        <div className="main_div">
            <div className="centre_div">
                <br />
                <input type="text"  value={input}/>
                <br />
                <div className="control">
                <AddIcon onClick={inputEvent} />
                <RestartAltIcon onClick={res} />
                <MinimizeIcon onClick={decre} />
                </div>
            
            </div>
        </div>
        </>
    )
}
export default App;