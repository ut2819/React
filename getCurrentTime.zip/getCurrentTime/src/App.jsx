import React, { useState } from "react";
import "./index.css";

const App=()=>{
     let newTime=new Date().toLocaleTimeString();

     const[cTime,setCTime]=useState(newTime);
     
     const updateTime=()=>{
        newTime=new Date().toLocaleTimeString();
         setCTime(newTime);
     }

    return(
    <>
     <div className="main">
     <h1>{cTime}</h1>
     <button onClick={updateTime}>get Time</button>
     </div>
    </>
    );

    }
export default App;
