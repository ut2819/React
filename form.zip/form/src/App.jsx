import React, { useState } from "react";
import "./index.css";

const App=()=>{
    const [fullName,setFullName]=useState({
        fName:"",
        lName:"",
        email:"",
        mob:""
    });
    const inputEvent=(event)=>{
        const value=event.target.value;
        const name=event.target.name;

        setFullName((preValue)=>{
            if(name==="fName"){
                return{ 
                    fName: value,
                    lName: preValue.lname,
                    email:preValue.email,
                    mob:preValue.mob,
                };
            }else if(name==="lName"){
                return{ 
                    fName:preValue.fName,
                    lName:value,
                    email:preValue.email,
                    mob:preValue.mob,
                };
            }else if(name==="email"){
                return{
                    fName:preValue.fName,
                    lName:preValue.lName,
                    email:value,
                    mob:preValue.mob
                };
            }else{
                return{
                    fName:preValue.fName,
                    lName:preValue.lName,
                    email:preValue.email,
                    mob:value,
                };
            }
        });
       };
    const onSubmit=(event)=>{
        event.preventDefault();
        alert("form submitted");
         
    }
    return(    
    <>
    <div className="main">
    <form onSubmit={onSubmit}>
    <h1>Hello  {fullName.fName} {fullName.lName} {fullName.email} {fullName.mob}</h1><br/>
    <input type="Text" name="fName" placeholder="Enter Your Name" onChange={inputEvent} value={fullName.fName}/><br/>
    <br/>  
    <input type="Text" name="lName" placeholder="Enter Your Password" onChange={inputEvent} value={fullName.lName} /><br/>
    <br/>  
    <input type="Text" name="email" placeholder="Enter Your Email" onChange={inputEvent} value={fullName.email} /><br/>
    <br/>  
    <input type="Text"  placeholder="Enter Your Phone Number" name="mob" onChange={inputEvent} value={fullName.mob} /><br/>
    <br/>
    <button type="submit" > Submit </button>
    </form>
    </div>
    </>
    
    );
    }
export default App;
