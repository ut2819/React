import React from "react";
import DeleteIcon from '@mui/icons-material/Delete';
import "./index.css";

const ToDoList=(props)=>{
    
   return(
    <>
    <div className="todo_style">
    <li>
       <DeleteIcon 
        onClick={()=>{
        props.onSelect(props.id);
    }} 
   className="delet"  /> {props.text} </li>
    </div>

    </>

   )
}
export default ToDoList;