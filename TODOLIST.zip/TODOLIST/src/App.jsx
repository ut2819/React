import React, { useState } from "react";
import "./index.css";

import ToDoList from "./ToDoList";
const App=()=>{
    const [inputList,setInputList]=useState("");
    const [Items,setItems]=useState([]);
    const inputEvent=(eve)=>{
       setInputList(eve.target.value);
    }
    const listOfItems=()=>{
         setInputList(" ");
         setItems((oldItems)=>{
            return [...oldItems, inputList ];
         });
    
    }
    const deleteItems=(id)=>{
        console.log("delete");
        setItems((oldItems)=>{
          return oldItems.filter((arrElement,index)=>{
             return id!==index; 
          })
        })
    }
    return(
        <>
        <div className="main_div">
            <div className="centre_div">
                <br />
                <h1>To Do List</h1>
                <br />
                <input type="text" placeholder="Add Items" onChange={inputEvent}  value={inputList}/>
                <button onClick={listOfItems}> + </button>
                <ol>
                    {/* <li>{inputList}</li> */}
                    {Items.map( (itemval,index)=>{
                        return(
                            <>
                            <ToDoList text={itemval}
                            id={index}
                            key={index}
                            onSelect={deleteItems}
                            />
                            </>
                    
                        )
                    })}
                </ol>
            </div>
        </div>
        </>
    )
}
export default App;