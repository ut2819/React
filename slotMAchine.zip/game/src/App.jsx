import React from "react";
import SlotM from './SlotM'
import "./index.css"
const App=()=>{
    return(
    <>
     <h1 className="Heading-Style">
        Welcome to{" "}
        <span style={{fontWeight:"bold"}}>Slot machine game</span>
        <hr />
        </h1>
        <div className="slotMachine">
        <SlotM x='😁' y='😁' z='😁' />
        <hr />
        <SlotM x='😁' y='🤣' z='😁' />
        <hr />
        <SlotM x='💕' y='😁' z='😁' />
        <hr />
        <SlotM x='😍' y='😍' z='😍' />
        <hr />
        </div> 
    </>
    );
}

export default App;
