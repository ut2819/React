import React, { useState } from "react";
import "./index.css";

const App=()=>{
     let newTime=new Date().toLocaleTimeString();

     const[cTime,setCTime]=useState(newTime);
     
     const updateTime=()=>{
        newTime=new Date().toLocaleTimeString();
         setCTime(newTime);
     }
    setInterval( updateTime,1000);
    return(
    <>
     <div className="main">
        <h1 className="Heading">
     {cTime}
         </h1>
     </div>
    </>
    );

    }
export default App;
